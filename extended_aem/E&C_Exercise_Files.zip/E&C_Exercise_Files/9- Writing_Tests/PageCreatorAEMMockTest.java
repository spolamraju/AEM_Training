package com.adobe.training.core.models;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.adobe.training.core.servlets.PageCreator;
import com.day.cq.tagging.TagManager;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;

/**
 * This class uses the AemContext object from AEM mocks to test the PageCreator Model.
 */
public class PageCreatorAEMMockTest {

	@Rule
	public AemContext context = new AemContext();	

	private PageCreator pageCreator;

	/**
	 * The setUp method loads the AemContext with services and resources to be used in the tests below.
	 */
	@Before
	public void setUp() {
		pageCreator = context.registerService(new PageCreator());

		context.load().json("/trainingproject-conf.json", "/conf/trainingproject/settings");
		
		context.create().page("/content/trainingproject/en","/conf/trainingproject/settings/wcm/templates/content-page","English");
		TagManager tm = context.resourceResolver().adaptTo(TagManager.class);
		try {
			tm.createTag("/content/cq:tags/we-retail/activity/biking", "Biking", "");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This test creates a POST request for the PageCreator class to validate
	 * a correct input for page creation
	 */
	@Test
	public void testSuccessfulInput() throws Exception{
		//Simulate a POST request
		context.request().setMethod("POST");
		context.request().setParameterMap(ImmutableMap.of(
				"importer","/content/trainingproject/en/community,Our Community,/conf/trainingproject/settings/wcm/templates/content-page,/content/cq:tags/we-retail/activity/biking,FALSE")
				);
		
		//Call the Servlet
		pageCreator.service(context.request(), context.response());
		assertEquals(HttpServletResponse.SC_OK, context.response().getStatus());

		String jsonString = context.response().getOutputAsString();
		ObjectMapper mapper = new ObjectMapper();
	    JsonNode actualObj = mapper.readTree(jsonString);
		assertEquals("Successful", actualObj.findValue("Status").asText());	
	}

	/**
	 * This test creates a POST request for the PageCreator class to validate
	 * if an error message is returned if there is no parent path given
	 */
	@Test
	public void testNoParentPath() throws Exception{
		//Simulate a POST request
		context.request().setMethod("POST");
		context.request().setParameterMap(ImmutableMap.of(
				"importer",",Our Community,/conf/trainingproject/settings/wcm/templates/content-page,/content/cq:tags/we-retail/activity/biking,FALSE")
				);

		//Call the Servlet
		pageCreator.service(context.request(), context.response());
		assertEquals(HttpServletResponse.SC_OK, context.response().getStatus());

		String jsonString = context.response().getOutputAsString();
		ObjectMapper mapper = new ObjectMapper();
	    JsonNode actualObj = mapper.readTree(jsonString);
		assertEquals("Error", actualObj.findValue("Status").asText());
	}
	
	/**
	 * This test creates a POST request for the PageCreator class to validate
	 * if the default template is used when none is given
	 */
	@Test
	public void testNoTemplate() throws Exception{
		//Simulate a POST request
		context.request().setMethod("POST");
		context.request().setParameterMap(ImmutableMap.of(
				"importer","/content/trainingproject/en/community,Our Community,,/content/cq:tags/we-retail/activity/biking,FALSE")
				);

		//Call the Servlet
		pageCreator.service(context.request(), context.response());
		assertEquals(HttpServletResponse.SC_OK, context.response().getStatus());

		String jsonString = context.response().getOutputAsString();
		ObjectMapper mapper = new ObjectMapper();
	    JsonNode actualObj = mapper.readTree(jsonString);
	    //Assert the default template is used
		assertEquals("/conf/trainingproject/settings/wcm/templates/content-page", actualObj.findValue("Template Used").asText());
	}
	
	/**
	 * This test creates a POST request for the PageCreator class to validate
	 * if an error message is returned because the template is not a valid template in the project.
	 */
	@Test
	public void testDNETemplate() throws Exception{
		//Simulate a POST request
		context.request().setMethod("POST");
		context.request().setParameterMap(ImmutableMap.of(
				"importer","/content/trainingproject/en/community,Our Community,/conf/trainingproject/settings/wcm/templates/mytemplate,/content/cq:tags/we-retail/activity/biking,FALSE")
				);

		//Call the Servlet
		pageCreator.service(context.request(), context.response());
		assertEquals(HttpServletResponse.SC_OK, context.response().getStatus());

		String jsonString = context.response().getOutputAsString();
		ObjectMapper mapper = new ObjectMapper();
	    JsonNode actualObj = mapper.readTree(jsonString);
	    
	    //Assert that the status is Error and a Template message is given
	    assertEquals("Error", actualObj.findValue("Status").asText());
		assertNotNull(actualObj.findValue("Template"));
	}
}
