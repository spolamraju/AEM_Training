package com.adobe.training.core.models;
 
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.Random;

import org.apache.sling.api.resource.Resource;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests the Stockplex model using the Mockito testing framework.
 * This is good for simple test cases, where the stubbing is fairly simple like in this example.
 * For more complex mocking, use the Sling Mock API or the AEM Mocks when AEM objects need to be mocked.
 * 
 * Note that the testable class is under /src/main/java:
 * com.adobe.training.core.models.Stockplex.java
 * 
 *  To correctly use this testing class:
 *  -put this file under training.core/src/test/java in the package com.adobe.training.core.models
 * 
 */
public class StockplexMockitoTest {
 
	private Stockplex stock;
	
    @Before
    public void setup() throws Exception {
    	
    	//Adapt the Resource if needed
    	Resource RESOURCE_MOCK = mock(Resource.class);
    	Stockplex STOCKMODEL_MOCK = mock(Stockplex.class);
    	when(RESOURCE_MOCK.adaptTo(Stockplex.class)).thenReturn(STOCKMODEL_MOCK);
    	
    	stock = STOCKMODEL_MOCK;
    	
    	//Setup stock symbol
    	final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        final int N = alphabet.length();
        Random r = new Random();
        String str = "";
        for (int i = 0; i < 4; i++) {
            str = str + alphabet.charAt(r.nextInt(N));
        }
    	when(STOCKMODEL_MOCK.getSymbol()).thenReturn(str);
    	
    	//Setup current trade price
    	Random rand = new Random();
    	double n = Math.round(100*(rand.nextInt(150) + 100)+rand.nextDouble())/100; //random value between 100.00 and 150.00
    	when(STOCKMODEL_MOCK.getCurrentPrice()).thenReturn(n);

    }
    
	@Test
	public void testGetLastTradeValue() throws Exception{
		assertNotNull("lastTradeModel is null", stock);
		assertTrue("current value is incorrect", stock.getCurrentPrice() > 100);
		assertFalse("stock symbol is incorrect", stock.getSymbol().isEmpty());
		
		
		// Verify that only those two methods were called on the mocked object
		verify(stock).getCurrentPrice();
		verify(stock).getSymbol();
		
		// Verify that no other interaction occurred on the mocked object
		verifyNoMoreInteractions(stock);
		
		// The one below is when we want to make sure that a specific method was never invoked 
		verify(stock, never()).getSummary();
	}

}