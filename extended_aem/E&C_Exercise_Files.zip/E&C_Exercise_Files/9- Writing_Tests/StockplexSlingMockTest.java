package com.adobe.training.core.models;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.factory.ModelFactory;
import org.apache.sling.testing.mock.sling.junit.SlingContext;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;


/**
 * Tests the Stockplex model using the Sling Mock implementation for Sling APIs
 *
 * A Sling context (the mock environment) needs to be created to test the classes.
 * The implementation used in that example is the ResourceResolver mock, 
 * to allow in-memory reading and writing resource data using the Sling Resource API.
 * 
 * It also provides support for Sling Models (Sling Models API 1.1 and Impl 1.1 or higher required)
 *
 * Note that the testable class is under /src/main/java:
 * com.adobe.training.core.models.Stockplex.java
 * 
 *  To correctly use this testing class:
 *  -put this file under training.core/src/test/java in the package com.adobe.training.core.models
 * 
 */


public class StockplexSlingMockTest {

	@Rule
	public final SlingContext context = new SlingContext();
	
	public String noDataString = "No stock data imported for this stock symbol";
	
	@Before
	public final void setup() throws Exception{
		//it may be required to register the models of this project manually depending on your project/IDE setup
	    context.addModelsForClasses(Stockplex.class);
	    //Load dummy data for imported stock data
	    context.load().json("/imported-stock-data.json","/content/stocks/");
	}
	
	/**
	   * Loads a page into the context via a JSON file and then tests the stock model can successfully return values
	   */
	  @Test
	  public void testLoadedContent() {
		  //Load a resource from JSON
		  Resource pageResource = context.load().json("/testpage-content.json", "/content/trainingproject/en/testpage");
		  Resource stockplexResource = pageResource.getChild("jcr:content/root/responsivegrid/stockplex");
		  context.request().setResource(stockplexResource);
		  
		  Stockplex model = context.getService(ModelFactory.class).createModel(context.request(), Stockplex.class);
		  
		  assertEquals("ADBE", model.getSymbol());
		  assertEquals("Adobe's stock price today", model.getSummary());
		  assertFalse(model.getSymbol().equals("MSFT"));
	  }
	  
	  /**
	   * Load a resource into the context with the create().resource method.
	   */
	  @Test
	  public void testCreatedContent() {
		  //Create a resource programmatically
		  Resource stockplexResource = context.create().resource("/content/mypage/jcr:content/root/responsivegrid/stockplex", ImmutableMap.<String,Object>builder()
		    		.put("jcr:primaryType", "nt:unstructured")
	                .put("jcr:createdBy", "admin")
	        		.put("summary", "Adobe's stock price today")
					.put("jcr:lastModifiedBy", "admin")
					.put("symbol", "ADBE")
					.put("jcr:created", "Thu Mar 21 2019 12:23:17 GMT-0400")
					.put("showStockDetails", "true")
					.put("jcr:lastModified", "Thu Mar 21 2019 12:23:34 GMT-0400")
					.put("sling:resourceType", "training/components/content/stockplex")
					.build());
		  context.request().setResource(stockplexResource);
		    
		  Stockplex model = context.getService(ModelFactory.class).createModel(context.request(), Stockplex.class);
			  
		  assertEquals("ADBE", model.getSymbol());
		  assertNotEquals("", model.getSummary());
		  assertFalse(model.getSymbol().equals("MSFT"));
	  }
	  
	  /**
	   * In this test we create a resource that uses the stockplex model. This model then looks for imported stock data 
	   * under /content/stocks/ADBE. Since ADBE stock was loaded, the expected outcome is the price being returned. 
	   */
	  @Test
	  public void testImportedStockData() {
		  String stockSymbol = "ADBE";
		  Resource stockplexResource = context.create().resource("/content/mypage/jcr:content/root/responsivegrid/stockplex", ImmutableMap.<String,Object>builder()
		    		.put("jcr:primaryType", "nt:unstructured")
		    		.put("symbol", stockSymbol)
		    		.put("sling:resourceType", "training/components/content/stockplex")
		    		.build());
		  context.request().setResource(stockplexResource);
		  Stockplex model = context.getService(ModelFactory.class).createModel(context.request(), Stockplex.class);
		  
		  assertNotEquals(0, model.getCurrentPrice()); //Validate there is stockprice
		  
		  Map<String, Object> data = ImmutableMap.<String,Object>builder().put(stockSymbol,noDataString).build();
		  assertNotEquals(data, model.getData()); //validate the data returned is stock the stock data
	  }
	  
	  /**
	   * In this test we create a resource that uses the stockplex model. This model then looks for imported stock data 
	   * under /content/stocks/APPL. Since APPL stock was not loaded, the expected outcome is 0 and data to be the 'noDataString'
	   */
	  @Test
	  public void testNoneExistantStockData() {
		  String stockSymbol = "APPL";
		  Resource stockplexResource = context.create().resource("/content/mypage/jcr:content/root/responsivegrid/stockplex", ImmutableMap.<String,Object>builder()
		    		.put("jcr:primaryType", "nt:unstructured")
		    		.put("symbol", stockSymbol)
		    		.put("sling:resourceType", "training/components/content/stockplex")
		    		.build());
		  context.request().setResource(stockplexResource);
		  Stockplex model = context.getService(ModelFactory.class).createModel(context.request(), Stockplex.class);
		  
		  assertEquals(Double.valueOf("0"), model.getCurrentPrice());
		  
		  Map<String, Object> data = ImmutableMap.<String,Object>builder().put(stockSymbol,noDataString).build();
		  assertEquals(data, model.getData());
	  }
}