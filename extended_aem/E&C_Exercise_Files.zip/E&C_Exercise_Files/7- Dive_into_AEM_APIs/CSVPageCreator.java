package com.adobe.training.core.servlets;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

import javax.jcr.Session;
import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This Servlet ingests a .csv file with the following columns:
 * 
 * New Page Path, Page Title, Page Tag, Auto Publish, Template
 *
 * And outputs AEM pages created. 
 * 
 * To test, you must create a content node with a resourceType=trainingproject/tools/pagecreator
 * 
 * /content/pagecreator {sling:resourceType=trainingproject/tools/pagecreator}
 *
 * Example cURL Command:
 * $ curl -u admin:admin -X POST http://localhost:4502/content/pagecreator.csv.json -F importer=@PageCreator.csv
 *
 */

@Component(	service = Servlet.class,
			property = {
					"sling.servlet.resourceTypes=trainingproject/tools/pagecreator",
					"sling.servlet.selectors=csv",
					"sling.servlet.methods=POST"
					}
			)
public class CSVPageCreator extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Reference
	private Replicator replicator;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)throws IOException {
		response.setContentType("application/json");
		HashMap<String, HashMap<String, String>> resultObject = new HashMap<>();

		String param = request.getParameter("importer");
		byte[] input = param.getBytes(StandardCharsets.UTF_8);
		InputStream stream = new ByteArrayInputStream(input);
		try {
			resultObject = readCSV(request, stream);
		} catch (Exception e) {
			logger.error("Failure to Read CSV: " + e);
		}

		ObjectMapper objMapper = new ObjectMapper();
		if (resultObject != null) {		
			//Write the result to the page
			response.getWriter().print(objMapper.writerWithDefaultPrettyPrinter().writeValueAsString(resultObject));
			response.getWriter().close();
		}
	}

	/**
	 * Reads the CSV file. The CSV file MUST be in the form of:
	 * <p>
	 * JCR path, Page Title, Page Template, AEM Tag, Publish boolean
	 *
	 * @param request resourceResolver will be derived from the request
	 * @param stream Stream from the CSV
	 * @return JSON object that contains the results of the page creation process
	 */
	private HashMap<String, HashMap<String, String>> readCSV(SlingHttpServletRequest request, InputStream stream) throws IOException, Exception {
		HashMap<String, HashMap<String, String>> out = new HashMap<>();

		String line;
		String[] newPage;
		HashMap<String, String> createdPageObject = null;

		try (BufferedReader br = new BufferedReader(new InputStreamReader(stream))) {
			//Read each line of the CSV
			while ((line = br.readLine()) != null) {
				newPage = line.split(",");
				String aemTag = null;
				String publishFlag = null;
				String aemTemplatePath = null;
	
				//If the line has a template, tag, publish flag, set those variables
				if (newPage.length == 5) {
					aemTemplatePath = newPage[2];
					aemTag = newPage[3];
					publishFlag = newPage[4];
				} else if (newPage.length == 4) {
					aemTemplatePath = newPage[2];
					aemTag = newPage[3];
				} else if (newPage.length == 3) {
					publishFlag = newPage[2];
				}
				String title = newPage[1]; //Add the Title of the new page
				String path = newPage[0]; //Add the creation path
				
				//Create a new page based on a line of input from the CSV
				createdPageObject = createTrainingPage(request, path, title, aemTemplatePath, aemTag, publishFlag);
	
				//add the status of the row into the json array
				out.put(title, createdPageObject);
				createdPageObject = null;
			}
		}
		return out;
	}

	/** Helper method to create the page based on available input
	 * 
	 * @param request resourceResolver will be derived from the request
	 * @param path JCR location of the page to be created
	 * @param title Page Title
	 * @param template AEM Template this page should be created from. The template must exist in the JCR already.
	 * @param tag Tag must already be created in AEM. The tag will be in the form of a path. Ex /etc/tags/marketing/interest
	 * @param publish boolean to publish the page
	 * @return HashMap
	 */
	private HashMap<String, String> createTrainingPage(SlingHttpServletRequest request, String path, String title, String template, String tagPath, String publish) {
		HashMap<String, String> pageInfo = new HashMap<>();
		pageInfo.put("Status","Error");
		
		if (path != null && !path.isEmpty()) {
			//Parse the path to get the pageNodeName and parentPath
			int lastSlash = path.lastIndexOf("/");
			String pageNodeName = path.substring(lastSlash + 1);
			String parentPath = path.substring(0, lastSlash);
			
			//Set a default template if none is given
			boolean invalidTemplate = false;
			if (template == null || template.isEmpty()) { //if no template has been given, assign the default
				template = "/conf/trainingproject/settings/wcm/templates/content-page";
			}
			else if(request.getResourceResolver().getResource(template) == null) { //check to see if the template exists
				invalidTemplate = true;
				pageInfo.put("Template","The template doesn not exist.");
			}
	
			//Create page
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
	
			Page p = null;
			//Verify parentPath exists, a node for this page exists, and the template is valid
			if (pageManager != null && !parentPath.isEmpty() && !pageNodeName.isEmpty() && !invalidTemplate) {
				if(title == null || title.isEmpty()) pageInfo.put("Warning","No Page title given");
				try {
					p = pageManager.create(parentPath,
							pageNodeName,
							template,
							title);
				} catch (WCMException e) {
					pageInfo.put("Error","Page couldn't be created.");
				}
				
				//Check to see if the page was successfully created
				if(p != null) {
					//Add a tag to the page
					if (tagPath != null && !tagPath.isEmpty()) {
						//TagManager can be retrieved via adaptTo
						TagManager tm = request.getResourceResolver().adaptTo(TagManager.class);
						Tag tag;
						try {
							tag = tm.createTag(tagPath, null, null);
							tm.setTags(p.getContentResource(), new Tag[] {tag}, true);
						} catch (Exception e) {
							pageInfo.put("Warning","Tag couldn't be read. Tag not added");
						} 
					}
		
					//Publish page if requested
					boolean publishPage = Boolean.parseBoolean(publish);
					if (publishPage && replicator != null) {
						//Replicator is exposed as a service
						try {
							replicator.replicate(request.getResourceResolver().adaptTo(Session.class),
									ReplicationActionType.ACTIVATE,
									p.getPath());
						} catch (ReplicationException e) {
							pageInfo.put("Warning","Page couldn't be published");
						}
					}
					
					pageInfo.put("Status", "Successful");
					pageInfo.put("Location", p.getPath());
					pageInfo.put("Title", p.getTitle());
					pageInfo.put("Template Used", p.getTemplate().getPath());
					String tags = "";
					for(Tag t : p.getTags() ) { tags = tags + t.getTitle() + " "; }
					pageInfo.put("Tagged with", tags);
					pageInfo.put("Was Published", String.valueOf(publishPage));
				}
			}
		}
		
		if(pageInfo.get("Status").contentEquals("Error")) {
			pageInfo.put("Error", "Page path, name, or template cannot be used.");
		}
		return pageInfo;
	}
}