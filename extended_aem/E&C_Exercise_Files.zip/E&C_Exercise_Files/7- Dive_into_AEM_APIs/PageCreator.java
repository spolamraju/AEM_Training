package com.adobe.training.core.servlets;

import java.io.IOException;
import java.util.HashMap;

import javax.jcr.Session;
import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This Servlet ingests a comma delimited string in the form of:
 * 
 * New Page Path, Page Title, Page Tag, Auto Publish, Template
 *
 * And outputs the AEM page created. 
 * 
 * To test, you must create a content node with a resourceType=trainingproject/tools/pagecreator
 * 
 * /content/pagecreator {sling:resourceType=trainingproject/tools/pagecreator}
 *
 * Example cURL Command:
 * $ curl -u admin:admin -X POST http://localhost:4502/content/pagecreator.json -F importer="/content/trainingproject/en/community,Our Community,/conf/trainingproject/settings/wcm/templates/content-page,/content/cq:tags/we-retail/activity/biking,TRUE"
 *
 */
@Component(service =  Servlet.class,
		   property = {"sling.servlet.resourceTypes=trainingproject/tools/pagecreator",
				       "sling.servlet.methods=POST"
		   })

public class PageCreator extends SlingAllMethodsServlet{

	private static final long serialVersionUID = 1L;

	@Reference
	private Replicator replicator;

    @Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)throws IOException{
		response.setContentType("application/json");
		HashMap<String, String> resultObject = new HashMap<>();
		
		String param = request.getParameter("importer");
		String[] newPage = param.split(",");

		resultObject = createTrainingPage(request, newPage[0], newPage[1], newPage[2], newPage[3], newPage[4]);

		ObjectMapper objMapper = new ObjectMapper();
		if(resultObject != null){
			//Write the result to the page
			response.getWriter().print(objMapper.writerWithDefaultPrettyPrinter().writeValueAsString(resultObject));
			response.getWriter().close();
		}
	}

	/** Helper method to create the page based on available input
	 * 
	 * @param request resourceResolver will be derived from the request
	 * @param path JCR location of the page to be created
	 * @param title Page Title
	 * @param template AEM Template this page should be created from. The template must exist in the JCR already.
	 * @param tag Tag must already be created in AEM. The tag will be in the form of a path. Ex /etc/tags/marketing/interest
	 * @param publish boolean to publish the page
	 * @return HashMap
	 */
	private HashMap<String, String> createTrainingPage(SlingHttpServletRequest request, String path, String title, String template, String tagPath, String publish) {
		HashMap<String, String> pageInfo = new HashMap<>();
		pageInfo.put("Status","Error");
		
		if (path != null && !path.isEmpty()) {
			//Parse the path to get the pageNodeName and parentPath
			int lastSlash = path.lastIndexOf("/");
			String pageNodeName = path.substring(lastSlash + 1);
			String parentPath = path.substring(0, lastSlash);
			
			//Set a default template if none is given
			boolean invalidTemplate = false;
			if (template == null || template.isEmpty()) { //if no template has been given, assign the default
				template = "/conf/trainingproject/settings/wcm/templates/content-page";
			}
			else if(request.getResourceResolver().getResource(template) == null) { //check to see if the template exists
				invalidTemplate = true;
				pageInfo.put("Template","The template doesn not exist.");
			}
	
			//Create page
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
	
			Page p = null;
			//Verify parentPath exists, a node for this page exists, and the template is valid
			if (pageManager != null && !parentPath.isEmpty() && !pageNodeName.isEmpty() && !invalidTemplate) {
				if(title == null || title.isEmpty()) pageInfo.put("Warning","No Page title given");
				try {
					p = pageManager.create(parentPath,
							pageNodeName,
							template,
							title);
				} catch (WCMException e) {
					pageInfo.put("Error","Page couldn't be created.");
				}
				
				//Check to see if the page was successfully created
				if(p != null) {
					//Add a tag to the page
					if (tagPath != null && !tagPath.isEmpty()) {
						//TagManager can be retrieved via adaptTo
						TagManager tm = request.getResourceResolver().adaptTo(TagManager.class);
						Tag tag;
						try {
							tag = tm.createTag(tagPath, null, null);
							tm.setTags(p.getContentResource(), new Tag[] {tag}, true);
						} catch (Exception e) {
							pageInfo.put("Warning","Tag couldn't be read. Tag not added");
						} 
					}
		
					//Publish page if requested
					boolean publishPage = Boolean.parseBoolean(publish);
					if (publishPage && replicator != null) {
						//Replicator is exposed as a service
						try {
							replicator.replicate(request.getResourceResolver().adaptTo(Session.class),
									ReplicationActionType.ACTIVATE,
									p.getPath());
						} catch (ReplicationException e) {
							pageInfo.put("Warning","Page couldn't be published");
						}
					}
					
					pageInfo.put("Status", "Successful");
					pageInfo.put("Location", p.getPath());
					pageInfo.put("Title", p.getTitle());
					pageInfo.put("Template Used", p.getTemplate().getPath());
					String tags = "";
					for(Tag t : p.getTags() ) { tags = tags + t.getTitle() + " "; }
					pageInfo.put("Tagged with", tags);
					pageInfo.put("Was Published", String.valueOf(publishPage));
				}
			}
		}
		
		if(pageInfo.get("Status").contentEquals("Error")) {
			pageInfo.put("Error", "Page path, name, or template cannot be used.");
		}
		return pageInfo;
	}
}