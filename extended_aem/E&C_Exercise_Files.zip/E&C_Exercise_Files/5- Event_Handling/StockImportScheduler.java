package com.adobe.training.core.schedulers;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.net.ssl.HttpsURLConnection;

import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrUtil;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
* This class imports stock data and creates the data structure example below:
* 
* /content/stocks/
*   + <STOCK_SYMBOL> [sling:OrderedFolder]
*     + trade [nt:unstructured]
*         	 - companyName = <value>
*       	 - sector = <value>
*           - lastTrade = <value>
*           - timeOfUpdate = <value>
*           - dayOfLastUpdate = <value>
*           - openPrice = <value>
*           - rangeHigh = <value>
*           - rangeLow = <value>
*           - volume = <value>
*           - upDownPrice = <value>
*           - week52High = <value>
*           - week52Low = <value>
*           - ytdChange = <value>
*LK, updated for GITHUB data, 190710
*/

@Component(service = Runnable.class, immediate = true)
@Designate(ocd = StockImportScheduler.Configuration.class, factory=true)
public class StockImportScheduler implements Runnable{
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	//Public values for stock data
	public static final String STOCK_IMPORT_FOLDER = "/content/stocks";
	public static final String COMPANY = "companyName";
	public static final String SECTOR = "sector";
	public static final String LASTTRADE = "lastTrade";
	public static final String UPDATETIME = "timeOfUpdate";
	public static final String DAYOFUPDATE = "dayOfLastUpdate";
	public static final String OPENPRICE = "openPrice";
	public static final String RANGEHIGH = "rangeHigh";
	public static final String RANGELOW = "rangeLow";
	public static final String VOLUME = "volume";
	public static final String UPDOWN = "upDown";
	public static final String WEEK52HIGH = "week52High";
	public static final String WEEK52LOW = "week52Low";
	public static final String YTDCHANGE = "ytdPercentageChange";
	
	
	@Reference
	private SlingRepository repo;
	
	//String to identify what stock to import
	private String symbol;
		
	//String to identify stock url
	private String stock_url;
	
	@Activate @Modified
	protected void activate(Configuration config) {
		symbol = config.symbol();
		stock_url = config.stock_url();
	}
	
	@ObjectClassDefinition(name = "Training Stock Importer")
	public @interface Configuration {
		@AttributeDefinition(
				name = "Stock Symbol",
				description = "Characters representing the stock to be imported",
				type = AttributeType.STRING
		)
		String symbol() default "";

		@AttributeDefinition(
			name = "Cron expression",
			description = "Run every so often as defined in the cron job expression.",
			type = AttributeType.STRING
		)
		String scheduler_expression() default "0/30 * * * * ?";
		
		@AttributeDefinition(
			name = "Stock URL",
			description = "URL to request the stock data to be imported",
			type = AttributeType.STRING
		)
		String stock_url() default "https://raw.githubusercontent.com/Adobe-Marketing-Cloud/ADLS-Samples/master/stock-data";

	}
	
	/**
	 * Method that runs on the desired schedule. 
	 * Request the data with the stock symbol and get the returned JSON
	 * Write the JSON to the JCR
	 */
	@Override
	public void run() {
		try {
			//url to be updated in the OSGI config 
			//String stockUrl = "<below url>";
			//https://raw.githubusercontent.com/Adobe-Marketing-Cloud/ADLS-Samples/master/stock-data
			String stockUrl = stock_url + "/" + symbol + ".json";

		    URL sourceUrl = new URL(stockUrl);
		    HttpsURLConnection request = (HttpsURLConnection) sourceUrl.openConnection();
		    request.connect();
		    
		    // Convert data return to a JSON object
		    ObjectMapper objMapper = new ObjectMapper();
		    JsonFactory factory = new JsonFactory();
		    JsonParser  parser  = factory.createParser(new InputStreamReader((InputStream) request.getContent()));	    
		    Map<String, String> allQuoteData = objMapper.readValue(parser,
		    	    new TypeReference<Map<String,String>>(){});
			
			logger.info("Last trade for stock symbol {} was {}", symbol, allQuoteData.get("latestPrice"));

			writeToRepository(symbol, allQuoteData);
			
		}
		catch (MalformedURLException e) {
			logger.error("MalformedURLException", e);
		}
		catch (IOException e) {
			logger.error("The stock symbol: " + symbol + " does not exist...");
		}
		catch (RepositoryException e) {
			logger.error("Cannot write stock info for " + symbol + " to the JCR:", e);
		}
		
		
	}
	
	/**
	 * Creates the stock data structure
	 * 
	 *  + <STOCK_SYMBOL> [sling:OrderedFolder]
	 *     + trade [nt:unstructured]
	 *     	 - companyName = <value>
	 *     	 - sector = <value>
	 *       - lastTrade = <value>
	 *       - timeOfUpdate = <value>
	 *       - dayOfLastUpdate = <value>
	 *       - openPrice = <value>
	 *       - rangeHigh = <value>
	 *       - rangeLow = <value>
	 *       - volume = <value>
	 *       - upDownPrice = <value>
	 *       - week52High = <value>
	 *       - week52Low = <value>
	 *       - ytdChange = <value>
	 */
	private void writeToRepository(String stockSymbol, Map<String, String> quoteData) throws RepositoryException {
		
		logger.info("Stock Symbol: " + stockSymbol);
		logger.info("JsonObject to Write: " + quoteData.toString());

		//Get the service user that belongs to the com.adobe.training.core:training subservice
		//Returns the training-user service user
		Session session= repo.loginService("training",null);
		
		//NOTE:  /content/stocks  has to exist in the JCR to successfully adapt resource to Node here. 
		boolean stockFolderExists = session.nodeExists(STOCK_IMPORT_FOLDER);
		
		Node parent;
		if(stockFolderExists) {
			parent = session.getNode(STOCK_IMPORT_FOLDER);
		}else {
			logger.warn("The node " + STOCK_IMPORT_FOLDER + " does not exist. Autocreating.");
			parent = JcrUtil.createPath(STOCK_IMPORT_FOLDER, "sling:OrderedFolder", session);
		}

		if (parent != null) {
			Node stockPageNode = JcrUtil.createPath(parent.getPath() + "/" + stockSymbol, "sling:OrderedFolder", session);
			Node tradeNode = JcrUtil.createPath(stockPageNode.getPath() + "/trade", "nt:unstructured", session);
			//use java.time api for Date & Time.  Set time to EST for our application
			ZoneId timeZone = ZoneId.of("America/New_York");			
			long latestUpdateTime = Long.parseLong(quoteData.get("latestUpdate"));
			LocalDateTime timePerLatestUpdate = LocalDateTime.ofInstant(Instant.ofEpochMilli(latestUpdateTime),
					timeZone);
			ZonedDateTime timeWithZone = ZonedDateTime.of(timePerLatestUpdate, timeZone);
			DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a zz");
			//will store timeOfUpdate as:  Hour:Minute AM/PM, TimeZone    e.g.   11:34 AM, EDT
			String iexUpdateTimeOfDay = timeWithZone.format(timeFormatter);
			DateTimeFormatter dayFormatter = DateTimeFormatter.ofPattern("E MMMM d, yyyy");
			String dayOfUpdate = timeWithZone.format(dayFormatter);
			tradeNode.setProperty(COMPANY, quoteData.get("companyName"));
			tradeNode.setProperty(SECTOR, quoteData.get("sector"));
			tradeNode.setProperty(LASTTRADE, Double.parseDouble(quoteData.get("latestPrice")));
			tradeNode.setProperty(UPDATETIME, iexUpdateTimeOfDay);
			tradeNode.setProperty(DAYOFUPDATE, dayOfUpdate);
			tradeNode.setProperty(OPENPRICE, Double.parseDouble(quoteData.get("open")));
			tradeNode.setProperty(RANGEHIGH, Double.parseDouble(quoteData.get("high")));
			tradeNode.setProperty(RANGELOW, Double.parseDouble(quoteData.get("low")));
			tradeNode.setProperty(VOLUME, Long.parseLong(quoteData.get("latestVolume")));
			tradeNode.setProperty(UPDOWN, Double.parseDouble(quoteData.get("change")));
			tradeNode.setProperty(WEEK52HIGH, Double.parseDouble(quoteData.get("week52High")));
			tradeNode.setProperty(WEEK52LOW, Double.parseDouble(quoteData.get("week52Low")));
			tradeNode.setProperty(YTDCHANGE, Double.parseDouble(quoteData.get("ytdChange")));
		} else {
			logger.error("###### JCR resource: " + STOCK_IMPORT_FOLDER + " needs to be created for Importer to write data");
		}
		session.save();
		session.logout();
	}
}
