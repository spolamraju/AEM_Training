package com.adobe.training.core.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * Test the training service user after its creation.
 *
 * Example URI: http://localhost:4502/bin/serviceuser.html
 *
 */

@Component(service = Servlet.class, property = { "sling.servlet.paths=/bin/serviceuser",
		"sling.servlet.extensions=html" })

public class SubServiceTester extends SlingSafeMethodsServlet {

	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	@Override
	protected void doGet(final SlingHttpServletRequest request, final SlingHttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Content-Type", "text/html");
		try (ServletOutputStream out = response.getOutputStream()) {
			out.println("Training User Tester<br/>");

			// Create a map with the service user subservice
			Map<String, Object> serviceParams = new HashMap<>();
			serviceParams.put(ResourceResolverFactory.SUBSERVICE, "training");

			// Create a ResourceResolver using the service user
			try (ResourceResolver resolver = resourceResolverFactory
					.getServiceResourceResolver(serviceParams)) {
				// Get service user info
				if (resolver.isLive()) {
					out.println("Training user created <b>sucessfully</b><br/>");
					out.println("User ID: " + resolver.getUserID() + "<br/>");
				}
				else
					out.println("Training user was <b>not</b> created<br/>");
			} 
			catch (LoginException le) {
				// The service user or subservice name does not exist or was improperly defined
				out.println("Service User Exception:<br/>");
				out.print(le.getMessage());
			}
		}
	}
}
